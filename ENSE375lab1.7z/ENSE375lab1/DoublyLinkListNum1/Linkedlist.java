public class Linkedlist {
    Node head; 
    class Node {
               int data;
                Node prev;
                Node next;
             Node(int x) { 
            data = x; }
        }
        public void push(int newData)
       {
           Node newNode = new Node(newData);
            newNode.next = head;
            newNode.prev = null;
 
            if (head != null)
            head.prev = newNode;
           head = newNode;
      }

     public void prepend(int newData)
    {
          Node newNode = new Node(newData);
            newNode.next = head;
            newNode.prev = null;
 
           if (head != null)
            head.prev = newNode;
        head = newNode;
    }
  

    void append(int newData)
    {
        Node newNode = new Node(newData);
 
        Node last = head; 
        newNode.next = null;

        if (head == null) {
            newNode.prev = null;
            head = newNode;
            return;
        }
        while (last.next != null)
            last = last.next;
        last.next = newNode;
        newNode.prev = last;
    }

    void deleteNode(Node y)
    {
        if (head == null || y == null) {
            return;
        }
        if (head == y) {
            head = y.next;
        }
        if (y.next != null) {
            y.next.prev = y.prev;
        }
        if (y.prev != null) {
            y.prev.next = y.next;
        }
        return;
    }
    public void printlist(Node node)
    {
        Node last = null;
        System.out.println("Print the List forward");
        while (node != null) {
            System.out.print(node.data + " \n");
            last = node;
            node = node.next;
        }
        System.out.println();
        System.out.println("Print the List backword");
        while (last != null) {
            System.out.print(last.data + "\n ");
            last = last.prev;
        }
    } 
    public static void main(String[] args) {
 
        Linkedlist list = new Linkedlist ();

        list.append(3);
        list.append(4);
        list.append(5);
        list.prepend(2);
        list.prepend(1);
 
        System.out.println("");
        list.printlist(list.head);

        list.deleteNode(list.head);
        list.deleteNode(list.head);
        list.printlist(list.head);

    }
}