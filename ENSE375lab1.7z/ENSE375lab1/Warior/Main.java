class Warrior {
  public void creatureType()
  {
    System.out.println("Creatures Type");   
  }
  public void attackType(){
      System.out.println("Attack Type");
  }
  public void movementType(){
      System.out.println("Movement Typec");
  }
 
}

class Knight extends Warrior{
  
  public void creatureType()  {
    System.out.println("The Knight is a Humanoid");   
  }
   public void attackType(){
      System.out.println("The Knight does a physical attack");
  }
  public void movementType(){
      System.out.println("The Knight walk");
  }
  
}

class Cleric extends Warrior {
  public void creatureType()
   {
    System.out.println("The Cleric is a Humanoid"); 
  }
  public void attackType(){
      System.out.println("The Cleric does a Magical attack");
  }
  public void movementType(){
      System.out.println("The Cleric Walk");
  }

}

class Skeleton extends Warrior {
  public void creatureType()
   {
    System.out.println("The Skeleton is Undead");  
  }
  public void attackType(){
      System.out.println("The Skeleton does a physical attack");
  }
  public void movementType(){
      System.out.println("The Skeleton Walk");
  }

}

class Ghost extends Warrior {
  public void creatureType()
   {
    System.out.println("The Ghost is Undead"); 
  }
  public void attackType(){
      System.out.println("The Ghost does a Magical attack");
  }
  public void movementType(){
      System.out.println("The Ghost teleport");
  }

}

class Birdbeing extends Warrior {
  public void creatureType()
   {
    System.out.println("The The Birdbeing is a Humanoid"); 
  }
  public void attackType(){
      System.out.println("The Birdbeing does a physical attack");
  }
  public void movementType(){
      System.out.println("The Birdbeing fly");
  }

}

class Lizardbeing extends Warrior {
  public void creatureType()
   {
    System.out.println("The Lizardbeing is a Humanoid");
  }
  public void attackType(){
      System.out.println("The Lizardbeing does a physical attack");
  }
  public void movementType(){
      System.out.println("The Lizardbeing walk");
  }

}

class Faire extends Warrior {
  public void creatureType()
   {
    System.out.println("The Faire is a Familiar");
  }
  public void attackType(){
      System.out.println("The Faire does a Magical attack");
  }
  public void movementType(){
      System.out.println("The Faire fly");
  }

}

class Gremlin extends Warrior {
  public void creatureType()
   {
    System.out.println("The Gremlin is a Familiar");
  }
  public void attackType(){
      System.out.println("The Gremlin does a physical attack");
  }
  public void movementType(){
      System.out.println("The Gremlin fly");
  }

}


class Dragon extends Warrior {
  public void creatureType()
   {
    System.out.println("The Dragon is a Monster");
  }
  public void attackType(){
      System.out.println("The Dragon does a physical attack");
  }
  public void movementType(){
      System.out.println("The Dragon fly");
  }

}


class Cyclops extends Warrior {
  public void creatureType()
   {
    System.out.println("The Cyclops is a Monster");
  }
  public void attackType(){
      System.out.println("The Cyclops does a Magical attack");
  }
  public void movementType(){
      System.out.println("The Cyclops walk");
  }

}

class Main {
  public static void main(String[] args) {
    Warrior myWarrior = new Warrior();
    Warrior myKnight = new Knight();
    Warrior myCleric = new Cleric();
    Warrior mySkeleton = new Skeleton();
    Warrior myGhost = new Ghost();
    Warrior myBirdbeing = new Birdbeing();
    Warrior myLizardbeing = new Lizardbeing();
    Warrior myFaire = new Faire();
    Warrior myGremlin = new Gremlin();
    Warrior myDragon = new Dragon();
    Warrior myCyclops = new Cyclops();
        
    myKnight.creatureType();
    myKnight.attackType();
    myKnight.movementType();
    
    myCleric.creatureType();
    myCleric.attackType();
    myCleric.movementType();

    mySkeleton.creatureType();
    mySkeleton.attackType();
    mySkeleton.movementType();
    
    myGhost.creatureType();
    myGhost.attackType();
    myGhost.movementType();
     
    myBirdbeing.creatureType();
    myBirdbeing.attackType();
    myBirdbeing.movementType();
     
    myLizardbeing.creatureType();
    myLizardbeing.attackType();
    myLizardbeing.movementType();
 
    myFaire.creatureType();
    myFaire.attackType();
    myFaire.movementType();
 
    myGremlin.creatureType();
    myGremlin.attackType();
    myGremlin.movementType();

    myDragon.creatureType();
    myDragon.attackType();
    myDragon.movementType();
     
    myCyclops.creatureType();
    myCyclops.attackType();
    myCyclops.movementType();
  }
}
